drop table players;
create table goals(
goal_id  text,
match_id text,
pid text,
duration int,
assist text,
goal_desc text
);
COPY goals (goal_id ,match_id ,pid,duration,assist,goal_desc  )
FROM 'C:\Program Files\PostgreSQL\17\data\UEFA_data\goals.csv' -- change this path accordingly
DELIMITER ','
CSV HEADER
ENCODING 'WIN1252';

create table matches
(
MATCH_ID VARCHAR(225) ,SEASON VARCHAR(225) ,DATE VARCHAR(225) ,
HOME_TEAM VARCHAR(225),AWAY_TEAM VARCHAR(225),STADIUM VARCHAR(225),
HOME_TEAM_SCORE int,
AWAY_TEAM_SCORE int,
PENALTY_SHOOT_OUT int,
ATTENDANCE int

);
COPY matches ( MATCH_ID  ,SEASON ,DATE  ,
HOME_TEAM ,AWAY_TEAM,STADIUM ,
HOME_TEAM_SCORE ,
AWAY_TEAM_SCORE ,
PENALTY_SHOOT_OUT ,
ATTENDANCE )
FROM 'C:\Program Files\PostgreSQL\17\data\UEFA_data\matches.csv' -- change this path accordingly
DELIMITER ','
CSV HEADER
ENCODING 'WIN1252';


create table players
(
PLAYER_ID VARCHAR(225),
FIRST_NAME VARCHAR(225),
LAST_NAME VARCHAR(225),
NATIONALITY VARCHAR(225),
DOB VARCHAR(225),
TEAM VARCHAR(225),
JERSEY_NUMBER Float,
pOSITION VARCHAR(225),
HEIGHT Float,
WEIGHT Float,
FOOT VARCHAR(225)


);
COPY players (PLAYER_ID, FIRST_NAME,LAST_NAME,NATIONALITY,DOB,TEAM,JERSEY_NUMBER,POSITION,HEIGHT,WEIGHT,FOOT)
FROM 'C:\Program Files\PostgreSQL\17\data\UEFA_data\players.csv' -- change this path accordingly
DELIMITER ','
CSV HEADER
;




create table teams(
TEAM_NAME VARCHAR(225) ,
COUNTRY VARCHAR(225) ,
HOME_STADIUM VARCHAR(225)
);
COPY teams (TEAM_NAME,COUNTRY,HOME_STADIUM)
FROM 'C:\Program Files\PostgreSQL\17\data\UEFA_data\teams.csv' -- change this path accordingly
DELIMITER ','
CSV HEADER
;
create table Stadium 
(
Name VARCHAR(225),
city VARCHAR(225),
country VARCHAR(225),
capacity int
);
COPY Stadium (Name,city,country,capacity)
FROM 'C:\Program Files\PostgreSQL\17\data\UEFA_data\Stadiums.csv' -- change this path accordingly
DELIMITER ','
CSV HEADER
;
select * from Stadium;
select * from matches;
select * from players;
select * from goals;




