select * from Stadium;
select * from matches order by match_id desc;
select * from players;
select * from goals;
select * from teams;
--goals
--1.	Which player scored the most goals in a each season?-- first counting and then max
select * from (select pid,max(sub.count_goals) over(partition by season) as max_in_season,season,count_goals from
(select distinct count(goal_id) over(partition by pid,season) as count_goals,pid,season  from goals g
inner join matches m  on
g.match_id=m.match_id where pid is not null order by 1 desc )sub ) where max_in_season=count_goals  ;
--2.	How many goals did each player score in a given season?
 select  distinct count(goal_id) over(partition by season,pid) as count_of_goals_by_this_player,season,pid  from goals g
inner join
matches m  on
g.match_id=m.match_id where pid is not null order by 1 desc;
--3.	What is the total number of goals scored in ‘mt403’ match?
select count(goal_id) as cnt from goals where match_id='mt403';
--4.	Which player assisted the most goals in a each season?
select distinct * from (select assist,max(sub.rank) over(partition by season)as max_in_season,rank,season from
(select count(goal_id) over(partition by season,assist) as rank,*  from goals g
inner join matches m  on
g.match_id=m.match_id )sub where assist is not null  order by season,rank desc) where max_in_season= rank order by season;
--5.	Which players have scored goals in more than 10 matches?
select count(distinct match_id) as cnt ,pid from goals group by pid having count(distinct match_id) >10;
--6.	What is the average number of goals scored per match in a given season?--per match per season
 select  round((count_of_goals_by_season::Float/count_of_match_per_season)::Numeric,2) as avg_goals_in_this_season_per_match
 ,season from (
 select count( distinct goal_id)  as count_of_goals_by_season,
 count(distinct m.match_id)  as count_of_match_per_season,
 season  from goals g
inner join
matches m  on
g.match_id=m.match_id group by season)sub order by 1 desc ;
--7.	Which player has the most goals in a single match?-1.count of goals per match by each player2.max
select * from 
(select max(cnt) over() as max_cnt,* from 
(select count(goal_id) as cnt ,pid,match_id from goals group by pid,match_id order by cnt desc))s where max_cnt=cnt;
--8.	Which team scored the most goals in the all seasons?
select * from 
(select max(total_goals) over(partition by season) as max_cnt,* from 
(select sum(score) total_goals,team, season from 
((select home_team as team,season ,sum(home_team_score) as score from matches group by season ,home_team)
union all
(select away_team,season,sum(away_team_score) from matches group by season ,away_team))s group by team,season order by 1 desc ))where max_cnt=total_goals;--limit 6;
--9.	Which stadium hosted the most goals scored in a single season?
select distinct count_of_goals_by_season_stadium,stadium,season from 
(select max(count_of_goals_by_season_stadium) over(
partition by season
)as max_goals_season_stadium,* from --max out of all stadium for a given season
(select count(goal_id) over(partition by season,stadium) as count_of_goals_by_season_stadium,*
from matches m inner join Stadium s on m.stadium=s.name
inner join goals g on g.match_id=m.match_id ) sub  order by season) where max_goals_season_stadium=count_of_goals_by_season_stadium;
;
--matches
select * from matches;

--10.	What was the highest-scoring match in a particular season?
select * from
(select max(total_score) over(partition by season) as max_score,total_score,match_id,season from 
(select sum(home_team_score+away_team_score) as total_score,match_id,season from matches group by match_id,season)
sub) where max_score=total_score ;
--11.	How many matches ended in a draw in a given season?
select count(distinct match_id) as total_draw from matches where home_team_score=away_team_score;

--12.	Which team had the highest average score (home and away) in the season 2021-2022?
select avg(score) avg_goals,team from 
((select home_team as team,home_team_score as score from matches where season='2021-2022')
union all
(select away_team,away_team_score from matches where season='2021-2022'))s group by team order by 1 desc  limit 1;


--select round(max(avg_score),2) as max_avg_score,home_team,away_team from 
--(select *,(home_team_score+away_team_score)/2.0 as avg_score from matches where season='2021-2022')sub group by home_team,away_team ;

--13.	How many penalty shootouts occurred in a each season?
select sum(penalty_shoot_out) as total_penalty,season from matches group by season;
--14.	What is the average attendance for home teams in the 2021-2022 season?
select round(avg(attendance),2) as avg_attendance,home_team from matches where season='2021-2022' group by home_team;
--15.	Which stadium hosted the most matches in a each season?
select * from (select distinct max(count_of_match_by_season_stadium) over(partition by season) as max_match,count_of_match_by_season_stadium ,stadium,season
from (select count(match_id) over(partition by season,stadium) as count_of_match_by_season_stadium,*
from matches m inner join Stadium s on m.stadium=s.name) sub order by season) where max_match=count_of_match_by_season_stadium;
--16.	What is the distribution of matches played in different countries in a season?
select count(match_id) as cnt,t.country,season from matches m inner join teams t on m.stadium=t.home_stadium 
group by t.country,season order by 1 desc;
--17.	What was the most common result in matches (home win, away win, draw)?
select count(*),match_res from (select  
case 
when home_team_score > away_team_score then 'home_win'
when home_team_score< away_team_score then 'away_win'
else 'draw'
end  as match_res from matches)s group by match_res order by 1 desc limit 1;
--
--players
select * from players;
--18.	Which players have the highest total goals scored (including assists)?
select * from (select sum(cnt) as total,pid from(
(select count(goal_id) as cnt ,pid from goals where pid is not null group by pid)
union all
(select count(goal_id),assist from goals where assist is not null group by assist))s group by pid order by 1 desc limit 1)s inner join players p 
on p.player_id=s.pid;
--19.	What is the average height and weight of players per position?
select avg(height) as avg_h,avg(weight) as avg_w ,position from players group by position;
--20.	Which player has the most goals scored with their left foot? same as 18
select max(s.total) ,pid from (
(select * from (select sum(cnt) as total,pid from(
(select count(goal_id) as cnt ,pid from goals where pid is not null group by pid)
union all
(select count(goal_id),assist from goals where assist is not null group by assist))s group by pid order by 1 desc )s inner join players p 
on p.player_id=s.pid
where foot='L'))s group by 2 order by 1 desc limit 1;
;
--21.	What is the average age of players per team?
SELECT 
    avg(EXTRACT(YEAR FROM (current_date))- 
    EXTRACT(YEAR FROM (TO_DATE(dob, 'DD-MM-YYYY')))) AS avg_in_years,team
FROM players group by team;
--22.	How many players are listed as playing for a each team in a season?--
select count(distinct p.player_id)
--+count(distinct g.assist)
as total_players,team,season from goals g inner join players p on p.player_id=g.pid or p.player_id=g.assist
inner join matches m on m.match_id=g.match_id group by season,team;
--23.	Which player has played in the most matches in the each season?
select maximium_match,season,player_id from (select distinct  max(t) over (partition by season) as maximium_match,t,season,player_id from
(select count( m.match_id) as t ,season,p.player_id from goals g inner join players p on p.player_id=g.pid or p.player_id=g.assist
inner join matches m on m.match_id=g.match_id group by season,p.player_id order by 1 desc )s  order by 1 desc) where t=maximium_match;
--24.	What is the most common position for players across all teams?
select count(*),position from players group by position order by 1 desc limit 1;
--25.	Which players have never scored a goal?
select player_id from players where  player_id not in (select distinct pid from goals);

--teams
select * from teams;
select * from stadium;
select * from matches;
--26.	Which team has the largest home stadium in terms of capacity?

select max_cap,team_name from (select max(c) over() as max_cap,* from 
(select max(capacity) as c,team_name from stadium s inner join teams t on s.name=t.home_stadium group by team_name order by 1 desc))s
where c=max_cap;
--27.	Which teams from a each country participated in the UEFA competition in a season?
select distinct t.country,t.team_name,m.season from matches m inner join teams t on home_team=team_name or away_team=team_name order by season;
--28.	Which team scored the most goals across home and away matches in a given season? same as 8
select sum(score) total_goals,team, season from 
((select home_team as team,season ,sum(home_team_score) as score from matches group by season ,home_team)
union all
(select away_team,season,sum(away_team_score) from matches group by season ,away_team))s group by team,season order by 1 desc ;
--29.	How many teams have home stadiums in a each city or country?--
select * from teams where home_stadium is null;
--30.	Which teams had the most home wins in the 2021-2022 season?
select count(*),home_team from (select  season,home_team,
case 
when home_team_score > away_team_score then 'home_win'
when home_team_score< away_team_score then 'away_win'
else 'draw'
end  as match_res from matches)s where match_res='home_win' group by home_team order by 1 desc limit 1;

select * from Stadium;
select * from matches order by match_id desc;
select * from players;
select * from goals;
select * from teams;
--31.	Which stadium has the highest capacity?
select * from Stadium order by capacity desc limit 1;
--32.	How many stadiums are located in a ‘Russia’ country or ‘London’ city?
select count(*) from Stadium where country='Russia' or city='London';
--33.	Which stadium hosted the most matches during a season?
select m_count,stadium,season from 
(select max(t) over(
partition by season
) as m_count,* from
(select count(match_id) as t,stadium,season from matches group by stadium,season)s)s1 where m_count=t ;
--34.	What is the average stadium capacity for teams participating in a each season?
select avg(capacity) as avg_capacity,season from matches m inner join stadium s on s.name=m.stadium group by season;
--35.	How many teams play in stadiums with a capacity of more than 50,000?--is it correct
select count(*) from ((select  distinct home_team as team from matches m inner join stadium s on s.name=m.stadium where s.capacity > 50000)
union 
(select  distinct away_team from matches m inner join stadium s on s.name=m.stadium where s.capacity > 50000));
--36.	Which stadium had the highest attendance on average during a season?--no.of matches doubt,which season
select * from 
(select * , max(avg_att) over(partition by season)as max_avg from
(select round(avg(attendance),2) as avg_att,stadium,season from matches group by stadium,season order by 1 desc)) where max_avg=avg_att;
;
--
select * from Stadium;
select * from matches order by match_id desc;
select * from players ;--where team='Bayern MÃ¼nchen'; --order by player_id desc;
select * from goals;
select * from teams;
--37.	What is the distribution of stadium capacities by country?
select avg(capacity),country from stadium group by country;
--38.	Which players scored the most goals in matches held at a specific stadium?

select count(goal_id) as count_of_goals,p.player_id from players p 
inner join goals g on g.pid=p.player_id or g.assist=p.player_id group by p.player_id order by 1 desc limit 1;
--39.	Which team won the most home matches in the season 2021-2022 (based on match scores)?--single quotes for values
select count(*),home_team from (select  season,home_team,
case 
when home_team_score > away_team_score then 'home_win'
when home_team_score< away_team_score then 'away_win'
else 'draw'
end  as match_res from matches)s where match_res='home_win' group by home_team order by 1 desc limit 1;
--40.	Which players played for a team that scored the most goals in the 2021-2022 season?
with max_team as (select 
--sum(score) total_goals,
team from 
((select home_team as team,home_team_score as score from matches where season='2021-2022')
union all
(select away_team,away_team_score from matches where season='2021-2022'))s group by team order by sum(score) desc
)
(select distinct pid,assist from  goals g inner join matches m
on g.match_id=m.match_id
where season='2021-2022' and (home_team in (select team from max_team) or away_team in (select team from max_team) ));

--41.	How many goals were scored by home teams in matches where the attendance was above 50,000?
(select sum(home_team_score) from matches where attendance>50000);
-- 42.	Which players played in matches where the score difference (home team score - away team score) was the highest?  -- in single column--ok
select distinct pid,assist from goals where match_id in (select match_id from (select max(diff) over() as m_d,* from 
(select match_id, abs(home_team_score - away_team_score) as diff from matches) ) where m_d=diff); 
--43.	How many goals did players score in matches that ended in penalty shootouts?
select * from matches where penalty_shoot_out>0;
--44.	What is the distribution of home team wins vs away team wins by country for all seasons?
 select distinct season,match_res,country from (select  season,stadium,
case 
when home_team_score > away_team_score then 'home_win'
when home_team_score< away_team_score then 'away_win'
else 'draw'
end  as match_res from matches)s inner join stadium k on k.name=stadium
where match_res='home_win' or  match_res='away_win' order by match_res,season;
--45.	Which team scored the most goals in the highest-attended matches?
select case
when home_team_score>away_team_score then "home_team"
else "away_team"
end "highest_attended_match_won" from matches order by attendance desc limit 1;
--46.	Which players assisted the most goals in matches where their team lost(you can include 3)?
--find which team lost then players who assisted
select count(goal_id) as count_of_goals,assist from (select * from (select  m.match_id,assist,p.team as "assist_team",g.goal_id,
case 
when home_team_score > away_team_score then "away_team"
when home_team_score< away_team_score then "home_team"
end  as lost_team from matches m
inner join goals g on g.match_id=m.match_id
inner join players p on g.assist=p.player_id) where lost_team is not null and assist_team=lost_team) group by assist 
having count(goal_id)>=3 
order by 1 desc;



select assist,p.team,* from goals g inner join matches m on g.match_id=m.match_id 
inner join players p on g.assist=p.player_id ;--where p.team
--47.	What is the total number of goals scored by players who are positioned as defenders?
select count(goal_id) from goals where pid in (select player_id from players where position ='Defender');
--48.	Which players scored goals in matches that were held in stadiums with a capacity over 60,000?
select pid from goals g inner join matches m on g.match_id=m.match_id where m.stadium in 
(select name from stadium where capacity>60000);
--49.	How many goals were scored in matches played in cities with specific stadiums in a season?
select count(goal_id),city,season from goals g inner join matches m on g.match_id=m.match_id inner join stadium s on s.name=m.stadium group by city,season;
--50.	Which players scored goals in matches with the highest attendance (over 100,000)?

select distinct pid from goals where match_id in (select match_id from matches where attendance >100000);
--
select * from Stadium;
select * from matches order by match_id desc;
select * from players;
select * from goals;
select * from teams;
--51.	What is the average number of goals scored by each team in the first 30 minutes of a match?

select avg(cnt) over(partition by match_id,team ) as avg_no_goal ,* from (select count(goal_id) over(partition by match_id,team ) as cnt,* from 
(select g.*,p.team,sum(duration) over(partition by match_id,team rows between unbounded preceding and current row) as cumulative_duaration from goals g
inner join players p on player_id=pid)
where cumulative_duaration <=30 order by match_id)
;
--52.	Which stadium had the highest average score difference between home and away teams?

select distinct stadium from (select max(avg_diff) over() as max_avg,* from (select avg(diff_score) over(partition by stadium) as avg_diff,* from
(select * ,(home_team_score-away_team_score) as diff_score from matches))) where max_avg=avg_diff
;
--53.	How many players scored in every match they played during a given season?
select distinct player_id,match_id,season from players p inner join matches m on m.home_team=p.team or m.away_team=p.team where player_id not in
(select distinct player_id from 
(select distinct player_id,match_id,season from players p inner join matches m on m.home_team=p.team or m.away_team=p.team 
group by season, player_id,match_id order by 1) ---players who played
where (player_id,match_id,season) not in 
(select distinct pid,g.match_id,season from goals g inner join matches m on g.match_id=m.match_id group by pid,g.match_id,season order by 1 )--players who scored goal
);
--54.	Which teams won the most matches with a goal difference of 3 or more in the 2021-2022 season?
select count(win_team),win_team from (select *,
case when diff_score > 3 then "home_team"
 when diff_score<-3 then "away_team"
end "win_team" from (select * ,(home_team_score-away_team_score) as diff_score from matches)where diff_score>3 or diff_score<-3) group by win_team
order by 1 desc limit 1;
--55.	Which player from a specific country has the highest goals per match ratio?



select round(m_ratio::NUMERIC,4) as max_ratio,round(ratio::NUMERIC,4) as ratio,pid,country from (select max(ratio)  over(partition by country ) as m_ratio,* from
(SELECT pid,country ,
       COUNT(DISTINCT goal_id):: FLOAT /COUNT(DISTINCT match_id) AS ratio
FROM goals
inner join players p on player_id=pid
inner join teams on team_name=p.team--where pid='ply765'
GROUP BY pid,country )ORDER BY m_ratio desc,ratio desc) where m_ratio=ratio;

select * from goals where pid='ply765' order by 2,3;